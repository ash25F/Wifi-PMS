
const crmDomain = 'indiestays-in.myfreshworks.com';
const  api_key = 'gh8ZNFhGfG_yf8mW63LkHQ';
const crmBasePath = "/crm/sales/api/";
let crmPath = "";

exports = {

  onAppInstallHandler: async function () {
        try{
        console.info('onAppInstallHandler invoked \n');
        const datetime = new Date();
        //console.log('datetime', datetime);
        const data = await $schedule.create({
          name: "Scheduled call to HK",
          data: {
            "event_info": "app_install"
          },
          schedule_at: datetime,
          repeat: {
            time_unit: "minutes",
            frequency: 30
          }
        });
        console.log("Schedule created: \n", JSON.stringify(data))
      }catch(error){
        console.info(error);
      }
    renderData();
  },
   
  onScheduledEventHandler: async function () {

    try{
        //*****************************call for hk API start *******************/
        const token = "OWE1YzBmMTYtMWIwNy00M2RjLTk0NjgtYWI2NTU3NGU1OTRhOjQzNTg5OTJjLTNhNDYtNDUyMy05Mzc2LThkOWNmZGRlNjFiNw==";
        const res =  await $request.invokeTemplate("getLeads", {
          context: {
            encondedToken : token
          }
        });
        const hkRes =  JSON.parse(res.response);
        const hkData = hkRes[0]["payload"];
        const bkData = {"token" : token,"reciept" : hkRes[0].receipt_handle};
        //*****************************call for hk API end *******************/
        console.info('hk response--', hkData);
        if(hkData.stream_name ==='Indiestays_Reservation')
          { //if the data is related to Indiestays
              console.info('stream id is correct');
              if(hkData.reservation.booking_status === 'BOOKED')
              {//*****booking event******/
                const contMobile = hkData.reservation.guest_info.phone;
                console.info("mobile number check...",typeof contMobile,  contMobile);
                if(typeof contMobile === "undefined" || contMobile === null || contMobile === '' || contMobile === "''")
                  {
                    console.info("process aborted as mobile number for contact is not available");
                    const acknowledgedBk = await ackPoll(bkData);
                    console.info("Poll Acknowledged...",acknowledgedBk);
              }else{
                    if(contMobile.length > 10){
                      const booking = await handleBooking(hkData);
                      console.info('new booking created...',booking);
                      if(typeof booking !== "undefined" || booking !== null){
                        acknowledgedBk = await ackPoll(bkData);
                        console.info("Poll Acknowledged after booking creation...",acknowledgedBk);
                      }else{
                        console.info("booking could not be created, check error logs..");
                      }
                    }else{
                      console.info("mobile number length doesn't meet the criteria..");
                      acknowledgedBk = await ackPoll(bkData);
                      console.info("Poll Acknowledged...",acknowledgedBk);
                }
               
              }
            }
              // else{
              //   //*****other than booking event******/\
              //   console.info("other than booking event block..");
              //   /**search contact by phone number and booking by confirmation number and add or update booking 
              //    * update contact details
              //   */
              // }
            }
            // else{
            //   console.info("Irrelevant stream recieved..", hkData.stream_id);
            //   const data = {
            //     "token" : token,
            //     "reciept" : hkRes[0].receipt_handle
            //   }
            //   const acknowledged = await ackPoll(data);
            //   console.info("Poll Acknowledged for irrelevant stram ID...",acknowledged);
            // }
  }catch(error){
      console.error('error from scheduled event handler--',error);
    }
  }
}

// async function getProducts(roomData, codes) {
//     //***************get product details start***********/
//     let filterVal = filterKey = "";
//     const dormCodes = ['BED8', 'BED6', 'BEDF', 'BED7', 'FBFD', 'SBMD', 'FBMD'];
//     const hkRoomCode = roomData.reservation.rate_details[0].room_type_code; //this is going blank
//     console.info('hkRoomCode', hkRoomCode, '=>', roomData.reservation.rate_details[0], '=>', roomData.reservation.rate_details[0].room_type_code);//check if this logic is running as expected for dorms
//     filterVal = (dormCodes.includes(hkRoomCode))?hkRoomCode:roomData.reservation.rate_details[0].room_type_name+" - "+ codes;
//     filterKey = (dormCodes.includes(hkRoomCode))?"product_code":"name";
//     const productObj = await $request.invokeTemplate("getProducts", {
//       body: JSON.stringify({ "filter_rule" : [{"attribute" : filterKey, "operator":"is_in", "value":filterVal}]}),
//       context: {
//         domain : crmDomain,
//         path : crmBasePath + "cpq/products/filterize",
//         api_key : api_key
//       }
//     });
//     console.info('productObj', productObj, codes);
//     parsedProductRes = JSON.parse(productObj.response);
//     //***************get product details end***********/
//     return parsedProductRes;   
// }

async function getSources(){
    //*************** get lead sources start ***********/
    try{
    const sourceObj = await $request.invokeTemplate("getLeadSources", {
      context: {
        domain : crmDomain,
        path : crmBasePath + "selector/lead_sources",
        api_key : api_key
      }
    });
    parsedSources = JSON.parse(sourceObj.response);
    return parsedSources;
  }catch(error){
    console.info('error while fetching sources...', error);
  }
}
/**
 * 
 * @param {*} contactData 
 * @param {*} terData 
 * @returns 
 */

async function handleContact(contactData, terData){
  console.info("from handlecontact..", contactData, terData[contactData.property_code].id);
  try{
      let contactObj = {};
      const parsedSourcesRes = await getSources();
      // console.info('parsedSourcesRes', parsedSourcesRes);
      const sourceObjs = parsedSourcesRes.lead_sources;
      const sourceEle = sourceObjs.find(o => o.name === contactData.source_name);
      // console.info("sourceEle", sourceEle);
      // const acctName = (typeof contactData.reservation.company_name === "undefined" || contactData.reservation.company_name === null)?"" : contactData.reservation.company_name;
      // response: '{"errors":{"code":400,"message":["The type for sales_accounts is invalid."]}}',
      //**********contact data******/
      contactObj = {'unique_identifier':{'mobile_number' : contactData.reservation.guest_info.phone},
      'contact': 
      {'first_name': contactData.reservation.guest_info.first_name,
        'last_name' : contactData.reservation.guest_info.last_name,
        'mobile_number' : contactData.reservation.guest_info.phone,
        'emails': [(typeof contactData.reservation.guest_info.email === "undefined" || contactData.reservation.guest_info.email=== null)?null:contactData.reservation.guest_info.email, (typeof contactData.reservation.guest_info.secondary_email=== "undefined" || contactData.reservation.guest_info.secondary_email === null)?null:contactData.reservation.guest_info.secondary_email],
        'lead_source_id': (typeof sourceEle === "undefined" || sourceEle === null)?null:sourceEle.id,
        'address' : (contactData.reservation.guest_info.street === null)?null:contactData.reservation.guest_info.street,
        'city': contactData.reservation.guest_info.city,
        'state' : contactData.reservation.guest_info.state,
        'zipcode' : contactData.reservation.guest_info.zip_code,
        'country' : contactData.reservation.guest_info.country,
        'sales_accounts' : {'name' : contactData.reservation.company_name},
        'territory_id' : terData[contactData.property_code].id,
        'custom_field': {'cf_no_shows' : contactData.reservation.rate_plan_detail.no_show_nights, 'cf_subject' : 'New Booking'},}};
        console.info('contactObj--', contactObj);          
        crmPath = crmBasePath + "contacts/upsert";
      /********calling api to push data to crm******/
      //"pushHKdata" : {},  from manifest
      const conResponse =  await $request.invokeTemplate("pushHKdata", {
          context: {
              path : crmPath,
              domain : crmDomain,
              api_key : api_key
            },
            body: JSON.stringify(contactObj)
          });
          
      // console.info('contact response--', conResponse);
      return conResponse;
    }catch(error){
      console.info("error from handleContact", error);
    }
}
/**
 * 
 * @param {*} bookingData 
 */
async function handleBooking(bookingData){
    let bookingObj = {};
  try{
      // const terRes = await getTerritories();
      // console.info('terRes from handlebooking', terRes, terRes[bookingData.property_code].short_code);

      let territories = [];
      const terRes = {};
      let propCode = "";
      //***************get territories start***********
      const teritoriesObj = await $request.invokeTemplate("getTerritories", {
        context: {
          domain : crmDomain,
          path : crmBasePath + "selector/territories",
          api_key : api_key
        }
      });    
      parsedTerritories = JSON.parse(teritoriesObj.response);
      console.info('parsedTerritories', parsedTerritories);
      
      parsedTerritories.territories.forEach(element => {
        if(element.name === 'Jaipur'){
          propCode = '7020';
          territories = {'name': element.name, 'id' : element.id, "short_code": "J"}; 
        } else if(element.name === 'Mumbai, Chembur'){
          propCode = '7052';
          territories = {'name': element.name, 'id' : element.id, "short_code": "C"}; 
        }else if(element.name === 'Mumbai, BKC'){
          propCode = '7004';
          territories = {'name': element.name, 'id' : element.id, "short_code": "BKC"}; 
        }else if(element.name === 'Goa'){
          propCode = '7024';
          territories = {'name': element.name, 'id' : element.id, "short_code": "G"}; 
        }else if(element.name === 'Mumbai International Airport'){
          propCode = '7055';
          territories = {'name': element.name, 'id' : element.id, "short_code": "Marol"}; 
        }else{
          return;
        }
        terRes[propCode] = territories;
      });
      console.log("terRes---", terRes);

      const propShortCode = terRes[bookingData.property_code].short_code;

      //***************get product details start***********/
    let filterVal = filterKey = "";
    const dormCodes = ['BED8', 'BED6', 'BEDF', 'BED7', 'FBFD', 'SBMD', 'FBMD'];
    const hkRoomCode = bookingData.reservation.rate_details[0].room_type_code; //this is going blank
    console.info('hkRoomCode', hkRoomCode, '=>', bookingData.reservation.rate_details[0], '=>', bookingData.reservation.rate_details[0].room_type_code);//check if this logic is running as expected for dorms
    filterVal = (dormCodes.includes(hkRoomCode))?hkRoomCode:bookingData.reservation.rate_details[0].room_type_name+" - "+ propShortCode;
    filterKey = (dormCodes.includes(hkRoomCode))?"product_code":"name";
    const productObj = await $request.invokeTemplate("getProducts", {
      body: JSON.stringify({ "filter_rule" : [{"attribute" : filterKey, "operator":"is_in", "value":filterVal}]}),
      context: {
        domain : crmDomain,
        path : crmBasePath + "cpq/products/filterize",
        api_key : api_key
      }
    });
    // console.info('productObj', productObj, codes);
    const productRes = JSON.parse(productObj.response);
    //***************get product details end***********/

      
      // const productRes = await getProducts(bookingData, propShortCode);
      // console.info ('productRes from handlebooking',productRes); 

      const conObj = await handleContact(bookingData,terRes);

      const conResObj = JSON.parse(conObj.response);
      console.info('conResObj from handlebooking', conResObj);
      const productPrice = bookingData.reservation.rate_details[0].rate_amount + bookingData.reservation.rate_details[0].total_taxes
      crmPath = crmBasePath + "deals";
      //*************************preparing booking data********************/
      bookingObj = {
        'name' : (bookingData.reservation.guest_info.first_name + ' ' + bookingData.reservation.guest_info.last_name + ' - ' + bookingData.reservation.room_rate),
        'sales_accounts' : {'name' : bookingData.reservation.company_name },
        'territory_id' : terRes[bookingData.property_code].id,
        'custom_field' : {
          'cf_booking_status' : 'Confirmed',
          'cf_booking_substatus' : 'Arrival',
          'cf_arrival_date' : bookingData.reservation.check_in_date,
          'cf_departure_date' : bookingData.reservation.check_out_date,
          'cf_booked_by' : bookingData.reservation.created_username,
          'cf_booking_date' : bookingData.reservation.booking_date,
          'cf_confirmation_number' : bookingData.reservation.reservation_no,
          'cf_rate_plan_code' : bookingData.reservation.rate_plan,
          'cf_cancellation_date' : (bookingData.reservation.cancellation_date === null || bookingData.reservation.cancellation_date === 'undefined')?null:bookingData.reservation.cancellation_date,
          'cf_adult' : bookingData.reservation.adult_count,
          'cf_children' : bookingData.reservation.child_count,
          'cf_external_confirmation_number': bookingData.reservation.external_reference_id,
          'cf_room_nights' : bookingData.reservation.room_count,
          'cf_po_number' : conResObj.contact.id,
          'cf_comments':bookingData.reservation.comments,
          'cf_market_segment' : bookingData.reservation.market_segment
        },
        'products' : [{"id": productRes.products[0].id,"quantity": 1,"unit_price": productPrice,}],
        'contact_ids': [conResObj.contact.id]
      }
      console.info('bookingObj...', bookingObj);
      /******************push deal to crm start ***********/
      const dealResponse =  await $request.invokeTemplate("pushDeal", {
        context: {
            path : crmPath,
            domain : crmDomain,
            api_key : api_key
          },
          body: JSON.stringify(bookingObj)
        });
        
      console.info('deal is created--', dealResponse);
      const dealResObj = JSON.parse(dealResponse.response);
      //console.info('dealResObj', dealResObj);
      return dealResObj;
}catch(error){
    console.error(error);
  }
}

async function ackPoll(pollData){
  const handle = {"receipt_handle" : pollData.reciept};

  // console.info('pollData', pollData);
    try{

    const res =  await $request.invokeTemplate("acknowledgePoll", {
      context: {
        encondedToken : pollData.token
      },
      body : JSON.stringify(handle)
    });
    // console.info('acknowledge res--',res);
    const hkRes =  res.status;
    return hkRes;
  }catch(error){
    console.error(error);
  }
}